import{c as d,l as x,r as j,m,j as e,F as y}from"./index-Cxul3sok.js";import{u as k,L as u}from"./useApiData-D-_RxG4B.js";import{D as p}from"./download-IMCuRFtu.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=d("FileJson",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 12a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1 1 1 0 0 1 1 1v1a1 1 0 0 0 1 1",key:"1oajmo"}],["path",{d:"M14 18a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-1a1 1 0 0 0-1-1",key:"mpwhp6"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=d("FileSpreadsheet",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=d("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=d("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);async function w(r,n){const o=await x.get(`/reports/${r}/download`,{params:{format:n},responseType:"blob"}),c=new Blob([o.data],{type:o.headers["content-type"]||"application/octet-stream"}),t=URL.createObjectURL(c),s=document.createElement("a");s.href=t,s.download=`${r}-report.${n}`,document.body.appendChild(s),s.click(),s.remove(),URL.revokeObjectURL(t)}const g={sales:y,products:h,customers:b,orders:h};function F(){const r=j.useCallback(()=>m(),[]),{data:n,loading:o,error:c}=k(r),t=async(a,l)=>{try{await w(a.id,l)}catch(i){alert(i instanceof Error?i.message:"خطا در دانلود گزارش")}},s=n?.find(a=>a.id==="orders");return e.jsxs("section",{className:"page",children:[e.jsx("div",{className:"page-head",children:e.jsxs("div",{children:[e.jsx("small",{children:"Reports"}),e.jsx("h2",{children:"مرکز گزارش‌ها"}),e.jsx("p",{className:"page-description",children:"گزارش‌ها و فایل خروجی از FastAPI تولید می‌شوند و داده‌ای داخل React نگهداری نمی‌شود."})]})}),o?e.jsx(u,{rows:4}):c?e.jsx("div",{className:"empty-inline",children:c}):e.jsx("div",{className:"report-grid",children:n?.filter(a=>a.id!=="orders").map((a,l)=>{const i=g[a.id];return e.jsxs("article",{className:"report-card",children:[e.jsx("span",{children:e.jsx(i,{size:24})}),e.jsxs("small",{children:["REPORT 0",l+1]}),e.jsx("h3",{children:a.title}),e.jsx("p",{children:a.description}),e.jsxs("div",{className:"report-actions",children:[e.jsxs("button",{type:"button",onClick:()=>t(a,"csv"),children:[e.jsx(p,{size:15})," CSV"]}),e.jsxs("button",{type:"button",onClick:()=>t(a,"json"),children:[e.jsx(v,{size:15})," JSON"]}),e.jsxs("button",{type:"button",onClick:()=>window.print(),children:[e.jsx(M,{size:15})," PDF / Print"]})]})]},a.id)})}),s&&e.jsxs("article",{className:"panel report-data-note",children:[e.jsx(h,{size:20}),e.jsxs("div",{children:[e.jsx("b",{children:"گزارش سفارش‌ها از Backend"}),e.jsx("small",{children:"فایل CSV مستقیم توسط FastAPI ساخته و دانلود می‌شود."})]}),e.jsxs("button",{type:"button",className:"secondary-action",onClick:()=>t(s,"csv"),children:[e.jsx(p,{size:16})," دانلود سفارش‌ها"]})]})]})}export{F as default};
