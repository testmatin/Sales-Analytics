import{c as n,d as x,r,j as e,U as j}from"./index-Cxul3sok.js";import{M as m}from"./mail-CVME772y.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=n("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=n("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=n("Save",[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=n("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);function C(){const i=x(),[s,c]=r.useState(i.profile),[t,d]=r.useState(!1);r.useEffect(()=>c(i.profile),[i.profile]);const l=(a,h)=>c(p=>({...p,[a]:h})),o=async()=>{try{await i.updateProfile(s),d(!0),window.setTimeout(()=>d(!1),1800)}catch(a){alert(a instanceof Error?a.message:"ذخیره پروفایل ناموفق بود")}};return e.jsxs("section",{className:"page profile-page",children:[e.jsx("div",{className:"page-head",children:e.jsxs("div",{children:[e.jsx("small",{children:"Account"}),e.jsx("h2",{children:"پروفایل کاربری"}),e.jsx("p",{className:"page-description",children:"اطلاعات حساب را ویرایش کن؛ تغییرات در فایل داده Backend ذخیره می‌شوند."})]})}),e.jsxs("div",{className:"profile-page-grid",children:[e.jsxs("article",{className:"panel profile-card-large",children:[e.jsx("div",{className:"profile-avatar-large",children:s.initials}),e.jsx("h3",{children:s.name}),e.jsx("p",{children:s.role}),e.jsxs("div",{className:"account-badge",children:[e.jsx(g,{size:16})," حساب مدیر • Demo"]}),e.jsxs("div",{className:"profile-contact",children:[e.jsxs("span",{children:[e.jsx(m,{size:16}),s.email]}),e.jsxs("span",{children:[e.jsx(v,{size:16}),s.phone]})]})]}),e.jsxs("article",{className:"panel profile-form-card",children:[e.jsxs("div",{className:"settings-section-head",children:[e.jsx(j,{size:20}),e.jsxs("div",{children:[e.jsx("h3",{children:"اطلاعات حساب"}),e.jsx("small",{children:"ویرایش اطلاعات نمایشی پروفایل"})]})]}),e.jsxs("div",{className:"form-grid",children:[e.jsxs("label",{children:[e.jsx("span",{children:"نام و نام خانوادگی"}),e.jsx("input",{value:s.name,onChange:a=>l("name",a.target.value)})]}),e.jsxs("label",{children:[e.jsx("span",{children:"سمت سازمانی"}),e.jsx("input",{value:s.role,onChange:a=>l("role",a.target.value)})]}),e.jsxs("label",{children:[e.jsx("span",{children:"ایمیل"}),e.jsx("input",{type:"email",value:s.email,onChange:a=>l("email",a.target.value)})]}),e.jsxs("label",{children:[e.jsx("span",{children:"تلفن"}),e.jsx("input",{value:s.phone,onChange:a=>l("phone",a.target.value)})]}),e.jsxs("label",{children:[e.jsx("span",{children:"حروف آواتار"}),e.jsx("input",{maxLength:3,value:s.initials,onChange:a=>l("initials",a.target.value.toUpperCase())})]})]}),e.jsxs("button",{type:"button",className:"primary-action",onClick:o,children:[t?e.jsx(u,{size:18}):e.jsx(f,{size:18})," ",t?"ذخیره شد":"ذخیره تغییرات"]})]})]})]})}export{C as default};
