import{c as a,d as o,a as l,j as e,o as c,p as r}from"./index-Cxul3sok.js";import{T as d}from"./trending-up-CeXZL5qz.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=a("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=a("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]),h={success:c,warning:x,info:p,trend:d};function y(){const i=o(),t=l();return e.jsxs("section",{className:"page",children:[e.jsxs("div",{className:"page-head",children:[e.jsxs("div",{children:[e.jsx("small",{children:"Notifications"}),e.jsx("h2",{children:"مرکز اعلان‌ها"}),e.jsx("p",{className:"page-description",children:"هشدارها، گزارش‌ها و رخدادهای مهم داشبورد."})]}),e.jsxs("button",{type:"button",className:"secondary-action",onClick:i.markAllNotificationsRead,children:[e.jsx(c,{size:17})," خواندن همه"]})]}),e.jsxs("article",{className:"panel notifications-page-list",children:[i.notifications.map(s=>{const n=h[s.type];return e.jsxs("button",{type:"button",className:`notification-page-row ${s.read?"":"unread"}`,onClick:()=>{i.markNotificationRead(s.id),t(s.route)},children:[e.jsx("span",{className:`notification-page-icon ${s.type}`,children:e.jsx(n,{size:19})}),e.jsxs("span",{children:[e.jsx("b",{children:s.title}),e.jsx("small",{children:s.message})]}),e.jsx("em",{children:s.time})]},s.id)}),!i.notifications.length&&e.jsxs("div",{className:"empty-state",children:[e.jsx(r,{size:28}),e.jsx("b",{children:"اعلانی وجود ندارد"})]})]})]})}export{y as default};
