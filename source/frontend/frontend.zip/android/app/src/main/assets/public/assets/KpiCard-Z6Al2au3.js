import{c as s,j as e}from"./index-Cxul3sok.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=s("ArrowDownRight",[["path",{d:"m7 7 10 10",key:"1fmybs"}],["path",{d:"M17 7v10H7",key:"6fjiku"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=s("ArrowUpRight",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=s("CircleDollarSign",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 18V6",key:"zqpxq5"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=s("CirclePercent",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"M9 9h.01",key:"1q5me6"}],["path",{d:"M15 15h.01",key:"lqbp3k"}]]);function x({label:r,value:c,growth:a,icon:t,accent:h="violet"}){const i=a>=0;return e.jsxs("article",{className:`kpi-card ${h}`,children:[e.jsxs("div",{className:"kpi-top",children:[e.jsx("span",{className:"kpi-icon",children:t}),e.jsxs("span",{className:i?"growth up":"growth down",children:[i?e.jsx(o,{size:14}):e.jsx(p,{size:14})," ",Math.abs(a),"٪"]})]}),e.jsx("p",{children:r}),e.jsx("strong",{children:c}),e.jsx("div",{className:"sparkline-bars","aria-hidden":"true",children:[36,52,44,62,57,73,68,84].map((n,l)=>e.jsx("i",{style:{height:`${n}%`}},l))})]})}export{k as C,x as K,y as a};
