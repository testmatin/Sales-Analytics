const a=t=>`${new Intl.NumberFormat("fa-IR",{notation:"compact",maximumFractionDigits:1}).format(t)} تومان`,o=t=>new Intl.NumberFormat("fa-IR").format(t);export{a,o as f};
