import{c as a,a as t,j as e}from"./index-Cxul3sok.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=a("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=a("SearchX",[["path",{d:"m13.5 8.5-5 5",key:"1cs55j"}],["path",{d:"m8.5 8.5 5 5",key:"a8mexj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);function r(){const s=t();return e.jsx("section",{className:"page",children:e.jsxs("div",{className:"not-found panel",children:[e.jsx(n,{size:36}),e.jsx("h2",{children:"صفحه پیدا نشد"}),e.jsx("p",{children:"مسیر موردنظر وجود ندارد یا جابه‌جا شده است."}),e.jsxs("button",{type:"button",className:"primary-action",onClick:()=>s("/"),children:[e.jsx(c,{size:17})," بازگشت به داشبورد"]})]})})}export{r as default};
